package com.carSale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarSaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
